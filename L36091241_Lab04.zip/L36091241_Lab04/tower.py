import pygame
import os
import math

TOWER_IMAGE = pygame.image.load(os.path.join("images", "rapid_test.png"))


class Circle:
    def __init__(self, center, radius):
        # set the (tower) center and radius
        self.center = center
        self.radius = radius

    def collide(self, enemy):
        """

        :param enemy: Enemy() object
        """

        """
        Hint:
        x1, y1 = enemy.get_pos()
        ...
        """
        # get the eneymy position
        x1, y1 = enemy.get_pos()
        # get the tower position
        x2, y2 = self.center

        # Calculate the distance by applying the Pythagorean theorem
        distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        # check whether the enemy is in the circle (attack range)
        if distance <= self.radius:
            # if the enemy is in range return True
            return True

    def draw_transparent(self, win):
        """
        Q1) draw the tower effect range, which is a transparent circle.
        :param win: window surface
        :return: None
        """
        # get the location of the center, given by class Tower and Tower groups
        x, y = self.center

        self.transparent_surface = pygame.Surface(
            (self.radius * 3, self.radius * 3), pygame.SRCALPHA)
        self.transparency = 100  # define transparency: 0~255, 0 is fully transparent
        # draw the circle on the transparent surface
        pygame.draw.circle(self.transparent_surface,
                           (150, 150, 150, self.transparency), [self.radius, self.radius], self.radius)
        # blit the circle at the right place by minus the radius,
        # otherwise, the circle appear at the bottom right corner of the image.
        win.blit(self.transparent_surface,
                 (x - self.radius, y - self.radius))
        pass


class Tower:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(
            TOWER_IMAGE, (70, 70))  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the tower
        self.range = 150  # tower attack range
        self.damage = 2   # tower damage
        # attack range circle (class Circle())
        self.range_circle = Circle(self.rect.center, self.range)
        self.cd_count = 0  # used in self.is_cool_down()
        self.cd_max_count = 60  # used in self.is_cool_down()
        self.is_selected = False  # the state of whether the tower is selected
        # if is_selected is denoted True, then at the start, all towers are selected.
        self.type = "tower"

    def is_cool_down(self):
        """
        Q2.1) Return whether the tower is cooling down
        (1) Use a counter to computer whether the tower is cooling down (( self.cd_count
        :return: Bool
        """

        if self.cd_count < self.cd_max_count:
            # if it's is on cool down, return True, and count up.
            self.cd_count += 1
            return True
        else:
            self.cd_count = 0
            # when the cool down is down, return False(ready to fire).
            return False

    def attack(self, enemy_group):
        """
        Q2.3) Attack the enemy.
        (1) check the the tower is cool down ((self.is_cool_down()
        (2) if the enemy is in attack range, then enemy get hurt. ((Circle.collide(), enemy.get_hurt()
        :param enemy_group: EnemyGroup()
        :return: None
        """

        if self.is_cool_down() == False:
            # check the cool down of tower first
            for enemy in enemy_group.get():
                # loop to get the enemy
                if self.range_circle.collide(enemy):
                    # check the if the enemy is in range
                    enemy.get_hurt(self.damage)
                    # return so the following enemy won't get hurt since the loop is cut-off.
                    return

    def is_clicked(self, x, y):
        """
        Bonus) Return whether the tower is clicked
        (1) If the mouse position is on the tower image, return True
        :param x: mouse pos x
        :param y: mouse pos y
        :return: Bool
        """
        mouse_x = x
        mouse_y = y
        # get the tower position
        tower_x, tower_y = self.rect.center

        # Calculate the distance by applying the Pythagorean theorem
        distance = math.sqrt((mouse_x - tower_x)**2 + (mouse_y - tower_y)**2)

        # return True if the distance between mouse and tower are small eneough,
        # 100 then the hitbox is a bit too big, 1 then I never click the Tower.
        if distance < 50:
            return True

        pass

    def get_selected(self, is_selected):
        """
        Bonus) Change the attribute self.is_selected
        :param is_selected: Bool
        :return: None
        """
        # so we can change the attribute of is_selected.
        self.is_selected = is_selected

    def draw(self, win):
        """
        Draw the tower and the range circle
        :param win:
        :return:
        """
        # draw range circle
        if self.is_selected:
            self.range_circle.draw_transparent(win)
        # draw tower
        win.blit(self.image, self.rect)


class TowerGroup:
    def __init__(self):
        self.constructed_tower = [
            Tower(250, 380), Tower(420, 400), Tower(600, 400)]

    def get(self):
        return self.constructed_tower
